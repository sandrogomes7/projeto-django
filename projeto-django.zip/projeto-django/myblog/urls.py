from rest_framework import routers
from .views import *

routerMyBlog = routers.DefaultRouter()
routerMyBlog.register(r'Professores', ProfessoresView)

routerMyBlog.register(r'Disciplinas', DisciplinasView)

routerMyBlog.register(r'Alunos', AlunosView)

routerMyBlog.register(r'PlanoAula', PlanoAulaView)

routerMyBlog.register(r'Atividade', AtividadeView)

routerMyBlog.register(r'AtividadeAluno', AtividadeAlunoView)

routerMyBlog.register(r'DisciplinaAluno', DisciplinaAlunoView)

routerMyBlog.register(r'Frequencia', FrequenciaView)

routerMyBlog.register(r'FrequenciaAluno', FrequenciaAlunoView)
